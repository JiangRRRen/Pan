package meta

//FileMeta: 定义文件结构的属性
type FileMeta struct{
	FileMD5 string //MD5作为文件ID
	FileName string //文件名
	FileSize int64 //大小
	FilePath string //本地存储路径
	TimeStamp string //时间戳
}

//目前元信息都存储在内存中，程序结束就会丢失，一般都会保存在数据库中
var fileMetas map[string]FileMeta

func init(){
	fileMetas=make(map[string]FileMeta) //初始化
}

//UpdateFileMeta: 更新文件信息
func UpdateFileMeta(f FileMeta){
	fileMetas[f.FileMD5]=f
}

//GetdateFileMeta: 根据MD5值获取文件信息
func GetdateFileMeta(md5 string) FileMeta{
	return fileMetas[md5]
}

//DeleteFileMeta: 简单的删除，线程不安全
func DeleteFileMeta(md5 string){
	delete(fileMetas,md5)
}
